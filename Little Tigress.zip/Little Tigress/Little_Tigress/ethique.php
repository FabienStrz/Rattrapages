<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Little Tigress Ethique</title>
    <link rel="stylesheet" href="style.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="container">
    <header>
        <div>
            <img src="img/logo_header.png" alt="" title="">
        </div>
        <div class="dl-menu" id="dl-menuwrapper">
            <!-- <button class="dl-trigger dl-active"></button> -->
            <nav class="dl-menu dl-menuopen">
                <ul class="ulNoPuce ulNav dl-submenu">
                    <li>
                        <a href="home.php" title="">Accueil</a>
                    </li>

                    <li>
                        <a href="shop.php" title="">Boutique</a>
                    </li>

                    <li>
                        <a href="about.php" title="">A propos</a>
                    </li>

                    <li>
                        <a href="ethique.php" title="">Ethique</a>
                    </li>

                </ul>
            </nav>
            <div>
                <img src="img/header_panier.png" alt="" title="">
                <button type="button" id="headerButtonAchetez">Achetez votre sac Little Tigress</button>
            </div>
        </div>
    </header>

    <footer>
        <div>
            <img src="img/footer_logo_text.png" alt="" title="" class="footerLogoText">
            <ul class="ulNoPuce ulSocialMedia">
                <li>
                    <a href="https://www.facebook.com/littletigressparis/" title="">
                        <img src="img/footer_facebook.png" title="Facebook" alt="">
                    </a>
                </li>

                <li>
                    <a href="https://www.instagram.com/littletigressparis/?hl=fr" title="">
                        <img src="img/footer_instagram.png" title="Instagram" alt="">
                    </a>
                </li>

                <li>
                    <a href="" title="">
                        <img src="img/footer_twitter.png" title="Twitter" alt="">
                    </a>
                </li>

            </ul>
        </div>
        <nav>
            <ul class="ulNoPuce ulNav">
                <li>
                    <a href="home.php" title="">Accueil</a>
                </li>

                <li>
                    <a href="shop.php" title="">Boutique</a>
                </li>

                <li>
                    <a href="about.php" title="">A propos</a>
                </li>

                <li>
                    <a href="ethique.php" title="">ethique</a>
                </li>

            </ul>
        </nav>
        <div>
            <h3 class="conditions">Conditions Générales de Vente Mentions légales</h3>
            <h3 class="cookies">En continuant sur notre site vous acceptez l’utilisation des cookies.</h3>
        </div>

    </footer>
</div>

</body>
</html>